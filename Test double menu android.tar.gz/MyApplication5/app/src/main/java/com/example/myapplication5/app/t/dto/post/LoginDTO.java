package com.example.myapplication5.app.t.dto.post;

import com.example.myapplication5.app.t.dto.technical.PostDTO;

/**
 * Created by florian on 10/11/14.
 */
public class LoginDTO extends PostDTO {

    protected String email;

    protected String password;

    public LoginDTO() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "LoginDTO{" +
                "email='" + email + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
