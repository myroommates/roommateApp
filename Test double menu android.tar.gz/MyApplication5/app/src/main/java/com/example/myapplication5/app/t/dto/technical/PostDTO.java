package com.example.myapplication5.app.t.dto.technical;

/**
 * Created by florian on 11/11/14.
 */
public class PostDTO extends DTO {

}
