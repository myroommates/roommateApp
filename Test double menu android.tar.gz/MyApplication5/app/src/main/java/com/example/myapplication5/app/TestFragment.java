package com.example.myapplication5.app;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.*;

/**
 * Created by florian on 8/02/15.
 */
public class TestFragment extends Fragment {

    public static final String ARG_MENU_NUMBER = "ARG_MENU_NUMBER";


    private View view;
    private MyPagerAdapter adapter;
    private ViewPager mViewPager;

    public static TestFragment newInstance(int sectionNumber) {
        TestFragment fragment = new TestFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_MENU_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        Log.w("cycle","onCreateView de TestFragment:"+getArguments().getInt(ARG_MENU_NUMBER));

        setHasOptionsMenu(true);
        view = inflater.inflate(R.layout.fragment_test, container, false);

        //force the menu refresh
       // getActivity().invalidateOptionsMenu();

        //build adapter
        adapter = new MyPagerAdapter(getArguments().getInt(ARG_MENU_NUMBER),getChildFragmentManager());

        // Inflate the layout for this fragment
        mViewPager = (ViewPager) view.findViewById(R.id.pager);
        mViewPager.setAdapter(adapter);

        return view;
    }
/*
    @Override
    public void onPrepareOptionsMenu(Menu menu) {

        assert getActivity().getActionBar() != null;

        //getActivity().getActionBar().setTitle(R.string.g_welcome);

        menu.clear();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }
    /*

    @Override
    public void onPrepareOptionsMenu(Menu menu) {

        adapter.getItem(adapter.getTabSelected()).onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return adapter.getItem(adapter.getTabSelected()).onOptionsItemSelected(item);
    }

     */

}
