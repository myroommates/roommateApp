package com.example.myapplication5.app;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.internal.app.WindowDecorActionBar;
import android.util.Log;
import android.view.*;

/**
 * Created by florian on 8/02/15.
 */
public class TestFragment extends Fragment  {//implements ActionBar.TabListener {

    public static final String ARG_MENU_NUMBER = "ARG_MENU_NUMBER";


    private View view;
    private ViewPager mViewPager;

    public static TestFragment newInstance(int sectionNumber) {
        TestFragment fragment = new TestFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_MENU_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        setHasOptionsMenu(true);
        view = inflater.inflate(R.layout.fragment_test, container, false);

        mViewPager = (ViewPager) view.findViewById(R.id.pager);
        if(savedInstanceState==null) {
            PagerAdapter myPagerAdapter = new MyPagerAdapter(getArguments().getInt(ARG_MENU_NUMBER), getChildFragmentManager());
            mViewPager.setAdapter(myPagerAdapter);
            //add tabLayout
            ((TabLayout) view.findViewById(R.id.sliding_tabs)).setViewPager(mViewPager);
        }



        return view;
    }
}
