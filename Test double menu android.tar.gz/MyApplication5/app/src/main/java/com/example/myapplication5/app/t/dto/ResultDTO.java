package com.example.myapplication5.app.t.dto;

import com.example.myapplication5.app.t.dto.technical.DTO;

/**
 * Created by florian on 19/11/14.
 */
public class ResultDTO extends DTO {
}
