package com.example.myapplication5.app;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import com.example.myapplication5.app.t.ShoppingItemListFragment;

/**
 * Created by florian on 8/02/15.
 */
public class MyPagerAdapter extends FragmentStatePagerAdapter {

    int menuSelected;
    int tabSelected;

    public MyPagerAdapter(int menuSelected, FragmentManager fm) {
        super(fm);
        this.menuSelected = menuSelected;
    }

    @Override
    public Fragment getItem(int i) {
        tabSelected = i;
        return ShoppingItemListFragment.newInstance(menuSelected, i);
    }

    @Override
    public int getCount() {
        return 2;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return "OBJECT " + (position + 1);
    }

}
