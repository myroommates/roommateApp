package com.example.myapplication5.app.t;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.*;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.example.myapplication5.app.R;
import com.example.myapplication5.app.StupidActivity;
import com.example.myapplication5.app.TestFragment;
import com.example.myapplication5.app.t.dto.ListShoppingItemDTO;
import com.example.myapplication5.app.t.dto.ShoppingItemDTO;
import com.example.myapplication5.app.t.externalRequest.RequestEnum;
import com.example.myapplication5.app.t.externalRequest.WebClient;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by florian on 4/12/14.
 */
public class ShoppingItemListFragment extends Fragment {

    private TextView adapter = null;
    private View view;
    private Animation refreshAnimation;
    private Menu menu;
    private List<ShoppingItemDTO> shoppingItemDTOList;
    private int sectionNb=0;


    private static final String ARG_SECTION_NUMBER = "ARG_SECTION_NUMBER";

    public static ShoppingItemListFragment newInstance(int menuNumber,int sectionNumber) {
        ShoppingItemListFragment fragment = new ShoppingItemListFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_SECTION_NUMBER, sectionNumber);
        args.putInt(TestFragment.ARG_MENU_NUMBER, menuNumber);
        fragment.setArguments(args);
        return fragment;
    }

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //load animation for refresh button
        refreshAnimation = AnimationUtils.loadAnimation(this.getActivity(), R.anim.rotation);
        refreshAnimation.setRepeatCount(Animation.INFINITE);

    }


    /**
     * create view, called the first time
     *
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {



        setHasOptionsMenu(true);

        //force the menu refresh
        getActivity().invalidateOptionsMenu();

        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_shopping, container, false);

        ((Button)     view.findViewById(R.id.click)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ShoppingItemListFragment.this.getActivity(), StupidActivity.class));
            }
        });

        //create adapter
        shoppingItemDTOList = new ArrayList<ShoppingItemDTO>();

        Log.w("cycle","onCreateView de ShoppingList:"+getArguments().getInt(TestFragment.ARG_MENU_NUMBER)+"/"+getArguments().getInt(ARG_SECTION_NUMBER));

        adapter = new TextView(getActivity());//,"je suis une text et je vais disssss paraitre  : !! "+);
        adapter.setText("je suis une text et je vais disssss paraitre !! "+getArguments().getInt(TestFragment.ARG_MENU_NUMBER)+"/"+getArguments().getInt(ARG_SECTION_NUMBER));


        //recover list
        LinearLayout listView = (LinearLayout) view.findViewById(R.id.list_insertion);

        //add adapter
        listView.addView(adapter);

        //add the contextual menu
        this.registerForContextMenu(listView);

        return view;
    }

    private enum SortEnum {
        DATE, ROOMMATE
    }


    /**
     * prepared the menu
     *
     * @param menu
     */
    @Override
    public void onPrepareOptionsMenu(Menu menu) {

        //getActivity().getActionBar().setTitle("nav shopping item");

        menu.clear();

        this.menu = menu;

        MenuInflater menuInflater = this.getActivity().getMenuInflater();
        menuInflater.inflate(R.menu.menu_shopping_item_list, menu);
        menu.findItem(R.id.b_refresh_shopping_item).setTitle("Refresh "+getArguments().getInt(TestFragment.ARG_MENU_NUMBER)+"/"+getArguments().getInt(ARG_SECTION_NUMBER));
    }

    /**
     * add event on menu item
     *
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        // Handle presses on the action bar items
        switch (item.getItemId()) {
            case R.id.b_add_shopping_item:

                return true;
            case R.id.b_refresh_shopping_item:
                RefreshRequest request = new RefreshRequest();
                request.execute();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void displayRefreshIcon(boolean display) {

        if (menu.findItem(R.id.b_refresh_shopping_item) != null) {
            if (display) {

                // create animation and add to the refresh item
                LayoutInflater inflater = (LayoutInflater) getActivity().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                ImageView iv = (ImageView) inflater.inflate(R.layout.loading_icon, null);
                menu.findItem(R.id.b_refresh_shopping_item).setActionView(iv);
                iv.startAnimation(refreshAnimation);
            } else {
                if (menu.findItem(R.id.b_refresh_shopping_item).getActionView() != null) {
                    menu.findItem(R.id.b_refresh_shopping_item).getActionView().clearAnimation();
                    menu.findItem(R.id.b_refresh_shopping_item).setActionView(null);
                }
            }
        }
    }

    /**
     * Refresh task.
     */
    private class RefreshRequest extends AsyncTask<String, Void, Void> {

        private ListShoppingItemDTO listShoppingItemDTO = null;
        private String errorMessage = null;

        @Override
        protected Void doInBackground(String... params) {

            WebClient<ListShoppingItemDTO> webClient = new WebClient<ListShoppingItemDTO>(RequestEnum.SHOPPING_ITEM_GET, ListShoppingItemDTO.class);
            try {
                listShoppingItemDTO = webClient.sendRequest();

            } catch (Exception e) {
                e.printStackTrace();
                errorMessage = e.getMessage();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {


            displayRefreshIcon(false);

            adapter.setVisibility(View.VISIBLE);

            if (errorMessage != null) {
                Log.e("test", "R.id.error_message_container");
            } else {
                Log.e("test", "R.id.error_message_container");

            }
        }

        @Override
        protected void onPreExecute() {
            adapter.setVisibility(View.GONE);
            displayRefreshIcon(true);
            Log.w("adapter","adapter into onPreExecute : ");
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            //display
        }

    }

}
