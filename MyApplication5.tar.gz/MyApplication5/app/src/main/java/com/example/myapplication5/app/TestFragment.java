package com.example.myapplication5.app;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.internal.app.WindowDecorActionBar;
import android.util.Log;
import android.view.*;
import android.widget.Toast;

/**
 * Created by florian on 8/02/15.
 */
public class TestFragment extends Fragment {//implements ActionBar.TabListener {

    public static final String ARG_MENU_NUMBER = "ARG_MENU_NUMBER";
    public static final String STATE_SELECTED_TAB = "STATE_SELECTED_TAB";


    private View view;
    private ViewPager mViewPager;
    private int menuNumber;

    public static TestFragment newInstance(int sectionNumber) {

        TestFragment fragment = new TestFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_MENU_NUMBER, sectionNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        menuNumber = getArguments().getInt(ARG_MENU_NUMBER);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_test, container, false);
        setHasOptionsMenu(true);

        mViewPager = (ViewPager) view.findViewById(R.id.pager);
        return view;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


        try {
            throw new Exception("onCreate FIRST TIME("+menuNumber+") !!: ");
        } catch (Exception e) {
            e.printStackTrace();
        }
        PagerAdapter myPagerAdapter = new MyPagerAdapter(menuNumber, getChildFragmentManager());
        mViewPager.setAdapter(myPagerAdapter);

        TabLayout tabLayout =((TabLayout) view.findViewById(R.id.sliding_tabs));
        tabLayout.setViewPager(mViewPager);
        mViewPager.setCurrentItem(1);


        if (savedInstanceState != null) {
            int currentSelectedTab=savedInstanceState.getInt(STATE_SELECTED_TAB);
            Toast.makeText(getActivity(), "onCreate - STATE_SELECTED_TAB("+menuNumber+") : " + currentSelectedTab, Toast.LENGTH_SHORT).show();
            try {
                throw new Exception("onCreate - STATE_SELECTED_TAB("+menuNumber+") : " + currentSelectedTab);
            } catch (Exception e) {
                e.printStackTrace();
            }
            mViewPager.setCurrentItem(currentSelectedTab);
        }
        else{
            Toast.makeText(getActivity(), "onCreate FIRST TIME("+menuNumber+") !!: ", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(STATE_SELECTED_TAB, mViewPager.getCurrentItem());
    }
}
