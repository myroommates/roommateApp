package com.example.myapplication5.app.t.externalRequest;

import android.util.Log;
import com.example.myapplication5.app.t.dto.ExceptionDTO;
import com.example.myapplication5.app.t.dto.technical.DTO;
import com.google.gson.*;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Date;


/**
 * Created by florian on 11/11/14.
 * Communicate with the serveur
 */
public class WebClient<U extends DTO> {

    //main url of the service
    //public final static String TARGET_URL = "http://192.168.1.8:9000/";
    //main url of the service - office
    //public final static String TARGET_URL = "http://192.168.18.190:9000/";
    //  test
    //public final static String TARGET_URL = "http://roommate-service.herokuapp.com/";
    //  official
    public final static String TARGET_URL = "http://roommate.herokuapp.com/";

    private final RequestEnum request;
    private String param1 = null;
    private Class<U> expectedResult;
    private DTO dto;

    public WebClient(RequestEnum request, Long id, Class<U> expectedResult) {
        this.request = request;
        this.param1 = String.valueOf(id);
        this.expectedResult = expectedResult;
    }

    public WebClient(RequestEnum request, DTO dto, Long id, Class<U> expectedResult) {
        this.request = request;
        this.dto = dto;
        this.param1 = String.valueOf(id);
        this.expectedResult = expectedResult;
    }

    public WebClient(RequestEnum request, DTO dto, String param1, Class<U> expectedResult) {
        this.request = request;
        this.dto = dto;
        this.param1 = param1;
        this.expectedResult = expectedResult;
    }

    public WebClient(RequestEnum request, Class<U> expectedResult) {
        this.request = request;
        this.expectedResult = expectedResult;
    }

    public WebClient(RequestEnum request, DTO dto, Class<U> expectedResult) {
        this.request = request;
        this.dto = dto;
        this.expectedResult = expectedResult;
    }

    /**
     * build, send and manage a http request.
     * Build the request by parameters of the request get
     */
    public U sendRequest() throws Exception {//RequestEnum request, DTO dto, Long id, Class<U> expectedResult) throws MyException {

        Thread.sleep(1500L);

        Log.w("webclient", "request :  " + request);

        //control request
        if (request == null) {
            throw new Exception("ya pas de requete ducon");
        }

        //control entrance
        if (request.getSentDTO() != null && !dto.getClass().equals(request.getSentDTO())) {
            throw new Exception("cest pas le bon DTO  : "+dto.getClass()+"/"+request.getSentDTO());
        }

        //initialize Gson
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

        gsonBuilder.registerTypeAdapter(Date.class, new JsonDeserializer() {
            public Date deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
                return new Date(json.getAsJsonPrimitive().getAsLong());
            }
        });

        Gson gson = gsonBuilder.create();

        //build url
        String urlString = TARGET_URL + request.getTarget();

        //add id into request if needed
        if (request.isRequestId()) {
            if (param1 == null) {
                throw new Exception("the request " + request.toString() + " needs an id");
            }
            urlString = urlString.replace(":param1", param1);
        }

        //initialize http client
        HttpClient httpClient = new DefaultHttpClient();

        //build the url request
        try {

            //build the url by requested by
            final HttpRequestBase httpRequest;

            switch (request.getRequestType()) {
                case GET:
                    httpRequest = new HttpGet(urlString);
                    break;
                case POST:
                    httpRequest = new HttpPost(urlString);
                    break;
                case DELETE:
                    httpRequest = new HttpDelete(urlString);
                    break;
                case PUT:
                    httpRequest = new HttpPut(urlString);
                    break;
                default:
                    throw new Exception("request type not found");
            }

            //
            //add params
            //

            //add Dto
            if (dto != null) {
                if (httpRequest instanceof HttpEntityEnclosingRequestBase) {
                    String json = gson.toJson(dto);
                    StringEntity params = new StringEntity(json);
                    ((HttpEntityEnclosingRequestBase) httpRequest).setEntity(params);
                    httpRequest.addHeader("content-type", "application/json");
                } else {
                    throw new Exception("cannot add dto into request type " + request.getRequestType().toString());
                }
            }

            //add authentication if it's needed
            /*
            if (request.needAuthentication()) {
                if (Storage.getAuthenticationKey() == null) {
                    throw new Exception("You need to be connected for this request : " + request.getTarget());
                }
                httpRequest.setHeader("authenticationKey", Storage.getAuthenticationKey());
            }
            */

            Log.w("webclient", "send request to " + urlString);

            //send request
            HttpResponse response = httpClient.execute(httpRequest);

            Log.w("webclient", "response : " + response.getStatusLine());
            Log.w("webclient", "response : " + response.getEntity().toString());

            if (response.getStatusLine().getStatusCode() == 200) {

                //receive response
                if (request.getReceivedDTO() != null) {

                    String jsonString = EntityUtils.toString(response.getEntity());

                    return gson.fromJson(jsonString, expectedResult);
                }
            } else {

                //error
                String jsonString = EntityUtils.toString(response.getEntity());
                Log.w("WebClient", "error with code " + response.getStatusLine().getStatusCode());


                try {
                    ExceptionDTO exception = gson.fromJson(jsonString, ExceptionDTO.class);
                    throw new Exception(exception.getMessage());
                } catch (JsonSyntaxException e) {
                    e.printStackTrace();
                    throw new Exception(jsonString);
                }
            }

            return null;

            // handle response here...
        } catch (IOException ex) {
            ex.printStackTrace();
            throw new Exception(ex.getMessage());
        } finally {
            httpClient.getConnectionManager().shutdown();
        }
    }
}
