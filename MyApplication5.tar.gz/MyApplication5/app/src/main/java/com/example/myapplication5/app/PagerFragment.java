//package com.example.myapplication5.app;
//
//import android.os.Bundle;
//import android.support.v4.app.Fragment;
//import android.support.v4.view.PagerAdapter;
//import android.support.v4.view.ViewPager;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//
//import java.util.ArrayList;
//import java.util.List;
//
///**
// * Created by florian on 10/02/15.
// */
//public class PagerFragment extends Fragment {
//
//    private static final String DATA_ARGS_KEY = "PagerFragment.DATA_ARGS_KEY";
//
//    private List<String> data;
//
//    private ViewPager pagerData;
//
//    public static PagerFragment newInstance(List<String> data) {
//        PagerFragment pagerFragment = new PagerFragment();
//        Bundle args = new Bundle();
//        ArrayList<String> argsValue = new ArrayList<String>(data);
//        args.putStringArrayList(DATA_ARGS_KEY, argsValue);
//        pagerFragment.setArguments(args);
//        return pagerFragment;
//    }
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        data = getArguments().getStringArrayList(DATA_ARGS_KEY);
//
//    }
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
//        View view =  inflater.inflate(R.layout.pager_fragment, container, false);
//        /*
//    }
//
//    @Override
//    public void onViewCreated(View view, Bundle savedInstanceState) {
//    */
//        pagerData = (ViewPager) view.findViewById(R.id.pager_data);
//        PagerAdapter adapter = new LocalPagerAdapter(getChildFragmentManager(), data);
//        pagerData.setAdapter(adapter);
//        return view;
//    }
//
//}
