package com.example.myapplication5.app;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by florian on 10/02/15.
 */
public class StupidActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stuipd);


    }
}
