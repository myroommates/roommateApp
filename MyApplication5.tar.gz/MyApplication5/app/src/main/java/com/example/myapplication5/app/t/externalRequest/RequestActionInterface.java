package com.example.myapplication5.app.t.externalRequest;


import com.example.myapplication5.app.t.dto.technical.DTO;

/**
 * Created by florian on 4/12/14.
 */
public interface RequestActionInterface {

    public void displayErrorMessage(String errorMessage);

    public void loadingAction(boolean loading);

    public void successAction(DTO successDTO);
}
