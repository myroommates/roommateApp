package be.flo.roommateapp.model.dto;

import be.flo.roommateapp.model.dto.technical.DTO;

/**
 * Created by florian on 19/11/14.
 */
public class ResultDTO extends DTO {
}
